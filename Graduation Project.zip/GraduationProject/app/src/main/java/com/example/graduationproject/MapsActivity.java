package com.example.graduationproject;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.example.graduationproject.databinding.ActivityMapsBinding;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    ActivityMapsBinding binding;
    private FusedLocationProviderClient fu;
    Location currentlocation;
private static final int Request_code =101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

fu= LocationServices.getFusedLocationProviderClient(MapsActivity.this);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.maps_fragment);
        mapFragment.getMapAsync(this);

    }
//private void getCurrentLocation() {
//    if (ActivityCompat.checkSelfPermission(
//            this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
//            this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},Request_code);
//        return;
//    }
//    LocationRequest locationRequest= LocationRequest.create();
//    locationRequest.setInterval(60000);
//    locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
//    locationRequest.setInterval(5000);
//    LocationCallback locationCallback=new LocationCallback() {
//        @Override
//        public void onLocationResult(@NonNull LocationResult locationResult) {
//            super.onLocationResult(locationResult);
//            Toast.makeText(MapsActivity.this, "locationResult is"+locationResult, Toast.LENGTH_SHORT).show();
//            if (locationRequest==null){
//                Toast.makeText(MapsActivity.this, "location Result is null"+locationResult, Toast.LENGTH_SHORT).show();
//return;
//            }
//            for (Location location:locationResult.getLocations()){
//                if (location!=null){
//                    Toast.makeText(MapsActivity.this, "locationResult is"+location.getLongitude(), Toast.LENGTH_SHORT).show();
//
//
//                }
//            }
//        }
//    };
//
//    Task<Location> task=fu.getLastLocation();
//    task.addOnSuccessListener(new OnSuccessListener<Location>() {
//        @Override
//        public void onSuccess(Location location) {
//            if (location!=null){
//                currentlocation=location;
//                Toast.makeText(MapsActivity.this, (int) currentlocation.getLatitude(), Toast.LENGTH_SHORT).show();
//                SupportMapFragment supportMapFragment=(SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.maps_fragment);
//                assert supportMapFragment!=null;
//                supportMapFragment.getMapAsync(MapsActivity.this);
//
//
//            }
//        }
//    });
//}

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (Request_code){
            case Request_code:
                if (grantResults.length>0 &&grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    getCountry();
                }
                break;
        }
    }
    private String getCountry() {
        if (ActivityCompat.checkSelfPermission(
                this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},Request_code);

        }
        String country_name = null;
        LocationManager lm = (LocationManager)getApplicationContext().getSystemService(Context.LOCATION_SERVICE);
        Geocoder geocoder = new Geocoder(getApplicationContext());
        for(String provider: lm.getAllProviders()) {
            @SuppressWarnings("ResourceType") Location location = lm.getLastKnownLocation(provider);
            if(location!=null) {
                try {
                    List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
                    if(addresses != null && addresses.size() > 0) {
                        country_name =addresses.get(0).getCountryName();
                        return country_name;
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        Toast.makeText(getApplicationContext(), country_name, Toast.LENGTH_LONG).show();
        return null;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
    @Override
    public void onMapClick(@NonNull LatLng latLng) {
        MarkerOptions markerOptions=new MarkerOptions();
        markerOptions.position(latLng);


        Geocoder geocoder = new Geocoder(MapsActivity.this, Locale.ENGLISH);
        try {
            List<Address> addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1);

            if(addresses != null) {
                Address returnedAddress = addresses.get(0);
                StringBuilder strReturnedAddress = new StringBuilder("Address:\n");
                for(int i=0; i<returnedAddress.getMaxAddressLineIndex(); i++) {
                    strReturnedAddress.append(returnedAddress.getAddressLine(i)).append("\n");
                }
markerOptions.title(strReturnedAddress.toString());

            }
            else{
                Toast.makeText(MapsActivity.this, "No Address returned!", Toast.LENGTH_SHORT).show();
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            Toast.makeText(MapsActivity.this, "Canont get Address!", Toast.LENGTH_SHORT).show();
        }
mMap.addMarker(markerOptions);
        Toast.makeText(MapsActivity.this, markerOptions.getTitle(), Toast.LENGTH_SHORT).show();

    }
});
mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
    @Override
    public boolean onMarkerClick(@NonNull Marker marker) {
        return false;
    }
});

    }
}

