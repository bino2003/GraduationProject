package com.example.graduationproject;

public interface ListenerOnClickItem {
    public void OnClickItem();
}
